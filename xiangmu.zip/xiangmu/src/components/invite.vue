<template>
  <div id="invite">
     <h2>invite page</h2>
  </div>
</template>

<script>
export default {
  name: "invite"
};
</script>

<style>

</style>
